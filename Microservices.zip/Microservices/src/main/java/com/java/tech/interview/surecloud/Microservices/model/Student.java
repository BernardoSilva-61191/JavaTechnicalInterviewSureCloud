package com.java.tech.interview.surecloud.Microservices.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Result")
public class Student {
	
	@Id
	@GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
	private UUID id;
	@Column(name = "name")
	private String name;
	@Column(name = "score")
	private int score;
	@Column(name = "date_taken")
	private Date date_taken;

	public Student () {
		
	}

	public Student(String name, int score, Date date_taken) {
		this.name = name;
		this.score = score;
		this.date_taken = date_taken;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Date getDate_taken() {
		return date_taken;
	}

	public void setDate_taken(Date date_taken) {
		this.date_taken = date_taken;
	}
	
	
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", score=" + score + ", date_taken=" + date_taken + "]";
	}
	

}
