package com.java.tech.interview.surecloud.Microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan({"com.java.tech.interview.surecloud.Microservices.controller","com.java.tech.interview.surecloud.Microservices.model", "com.java.tech.interview.surecloud.Microservices.repository"})
@RestController

public class MicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesApplication.class, args);
	}

}
