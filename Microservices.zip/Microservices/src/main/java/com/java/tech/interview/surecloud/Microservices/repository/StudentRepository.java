package com.java.tech.interview.surecloud.Microservices.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.java.tech.interview.surecloud.Microservices.model.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, UUID> {
	
	List<Student> findByNameContaining(String name);
}
